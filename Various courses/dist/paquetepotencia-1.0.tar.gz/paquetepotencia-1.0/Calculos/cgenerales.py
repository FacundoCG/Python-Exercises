def suma(n1,n2):
    print('El resultado de la suma es: ',n1+n2)

def resta(n1,n2):
    print('El resultado de la resta es: ',n1-n2)

def mult(n1,n2):
    print('El resultado de la multiplicación es: ',n1*n2)

def dividir(n1,n2):
    print('El resultado de división es: ',n1/n2)

def redondear(n1):
    print('El resultado de redondear el numero es: ',round(n1))

